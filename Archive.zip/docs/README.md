# Calculatrice de distributions

Pour calculatrice voir: https://alec42.shinyapps.io/distributacalcul/

Pour wiki de distributions voir: https://gitlab.com/alec42/distributacalcul-wiki/wikis/Home

Pour site du projet voir: https://alec42.github.io/distributacalcul/

Pour le package en développement voir: https://github.com/alec42/distributacalcul_package
